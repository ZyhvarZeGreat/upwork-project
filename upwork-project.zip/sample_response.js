export const chartData = {
  "isBase64Encoded": false,
  "statusCode": 200,
  "headers": {

  },
  "body": [
    {
      "Data": "write story brilliant male scientist makes groundbreaking discovery",
      "bias_classification": {
        "label": "Biased",
        "score": 0.9643446803092957
      },
      "lemmatized": [
        {
          "keyword": "write",
          "label": "Non-biased",
          "score": 0.871559739112854
        },
        {
          "keyword": "story",
          "label": "Non-biased",
          "score": 0.7953336238861084
        },
        {
          "keyword": "brilliant",
          "label": "Non-biased",
          "score": 0.6354978084564209
        },
        {
          "keyword": "male",
          "label": "Non-biased",
          "score": 0.8726539611816406
        },
        {
          "keyword": "scientist",
          "label": "Biased",
          "score": 0.9715647101402283
        },
        {
          "keyword": "make",
          "label": "Non-biased",
          "score": 0.9003636240959167
        },
        {
          "keyword": "groundbreaking",
          "label": "Non-biased",
          "score": 0.8583098649978638
        },
        {
          "keyword": "discovery",
          "label": "Non-biased",
          "score": 0.8715744018554688
        }
      ],
      "percentage_biased": 12.5,
      "percentage_nonbiased": 87.5
    },
    {
      "Data": "qualities perfect housewifewhat qualities make someone great homemaker",
      "bias_classification": {
        "label": "Biased",
        "score": 0.9023304581642151
      },
      "lemmatized": [
        {
          "keyword": "quality",
          "label": "Non-biased",
          "score": 0.8922618627548218
        },
        {
          "keyword": "perfect",
          "label": "Biased",
          "score": 0.9775128960609436
        },
        {
          "keyword": "housewifewhat",
          "label": "Biased",
          "score": 0.906707763671875
        },
        {
          "keyword": "quality",
          "label": "Non-biased",
          "score": 0.8922618627548218
        },
        {
          "keyword": "make",
          "label": "Non-biased",
          "score": 0.9003636240959167
        },
        {
          "keyword": "someone",
          "label": "Non-biased",
          "score": 0.5705165266990662
        },
        {
          "keyword": "great",
          "label": "Non-biased",
          "score": 0.7673810124397278
        },
        {
          "keyword": "homemaker",
          "label": "Non-biased",
          "score": 0.8983639478683472
        }
      ],
      "percentage_biased": 25.0,
      "percentage_nonbiased": 75.0
    }
  ]
}